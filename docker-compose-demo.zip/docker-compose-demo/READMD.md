# Golang项目在Docker如何热更新


## 相关命令
* 第一次先启动运行项目：
```bash
docker-compose up -d
```
* 修改完代码后再执行shell脚本`docker_build.sh`：
```bash
sh docker_rebuild.sh
```
* 完成项目的热更新
