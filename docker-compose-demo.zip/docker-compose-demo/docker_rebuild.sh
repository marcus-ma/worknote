#!/bin/sh
docker-composer stop go-http-server  # stop only one. but it still running !!!
docker-compose build --no-cache go-http-server # rebuild the image
docker-compose up -d # run all services
echo "ok"