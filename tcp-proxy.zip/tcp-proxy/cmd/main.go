package main

import (
	"context"
	"fmt"
	"log"
	"net"
	"tcp-proxy/tcp_proxy"
)

var (
	addr = ":2002"
)

type tcpHandler struct {

}

func (t *tcpHandler) ServeTCP(ctx context.Context,src net.Conn)  {
	src.Write([]byte("tcpHandler\n"))
}



func main() {
	//可做redis/mysql代理
	log.Println("Starting tcpserver at "+addr)
	tcpServ := tcp_proxy.TcpServer{
		Addr: addr,
		Handler: tcp_proxy.NewTcpLoadBalanceReverseProxy(":6379"),
	}
	fmt.Println("Starting tcpserver at "+addr)
	tcpServ.ListenAndServe()
}
